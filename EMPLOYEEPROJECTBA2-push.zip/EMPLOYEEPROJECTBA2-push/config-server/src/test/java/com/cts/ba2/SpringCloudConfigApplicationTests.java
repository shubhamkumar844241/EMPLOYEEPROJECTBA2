package com.cts.ba2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
